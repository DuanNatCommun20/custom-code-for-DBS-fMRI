clc;clear
save_path = 'H:\Opto_test\Neurons_20190704_01\20190704_214809_OG_test_1_11\Functions\Allscans_40HZ\';
codepath = 'F:\DataAnalysis\code_for_mice_taskfMRI\';
addpath(genpath(codepath));
mouse_path{1} = 'H:\Opto_test\Neurons_20190704_01\20190704_214809_OG_test_1_11\';
% mouse_path{2} = 'H:\Opto_test\20190615_203803_IP3R2_Opto_1_19';
% mouse_path{3} = '';

EPI_folder{1} = [15 18 23];
% EPI_folder{2} = [10 13];
% EPI_folder{3} = [];

ROI = {'LGN';'M1';'VC';};

%% Time series extraction

for number = 1:numel(mouse_path)
    path = mouse_path{number};
    folder = EPI_folder{number};
    for kk = folder
        cd([path 'Results\' num2str(kk)]);
        fMRI_data = spm_read_vols(spm_vol('snbrsmImage.nii'));
        for index = 1:numel(ROI)
            cd([codepath '\seed_point\40HZ\']);
            ROI_mask = spm_read_vols(spm_vol([ROI{index},'.nii']));
            ram = mean(fmask(fMRI_data,ROI_mask),1);
            dest = [path '\Functions\tsfMRI\' num2str(kk)];
            if ~exist(dest,'dir');mkdir(dest);end
            cd(dest);
            save([ROI{index},'.mat'],'ram');
        end
    end
end
%}

%% multi-block stimulus across individual scan
%
stimulus_paradigm = [zeros(1,40) ones(1,20) zeros(1,40) ones(1,20) zeros(1,40) ones(1,20) zeros(1,40) ones(1,20) zeros(1,40)];
for index = 1:numel(ROI)
    for number = 1:numel(mouse_path)
        path = mouse_path{number};
        folder = EPI_folder{number};
        for kk = folder
            cd([path '\Functions\tsfMRI\' num2str(kk)])
            load([ROI{index},'.mat']);
            cd([path '\Results\' num2str(kk)]);
            rp = load('rp_smImage.txt');
            RegBasFuc = [ones(length(rp),1),(1:length(rp))'];%,rp
            [Beta,~,Residual] = regress(ram(:),RegBasFuc);
            ram = Residual + Beta(1);
            ram_baseline = mean(ram(stimulus_paradigm==0));
            ram = (ram-ram_baseline)/ram_baseline*100;
            %% Figure plot
            Series(1) = struct('name',ROI{index},'data',ram,'stimulus',stimulus_paradigm);
            title_txt = ROI{index};
            F = MY_get_figure_ROI_Time_Course_multi_stimulus_individual_scan(Series,title_txt);
            cd([path '\Functions\tsfMRI\' num2str(kk)])
            saveas(F,[ROI{index},'.tif'])
            close all;clear ra*
        end
    end
    
end
%}
%% sigle stimulus across all scans
 
stimulus_paradigm = [zeros(1,10) ones(1,20) zeros(1,30)];
for index = 1:numel(ROI)
    %% Series reshape
    ram_data = [];
    for number = 1:numel(mouse_path)
        path = mouse_path{number};
        folder = EPI_folder{number};
        for kk = folder
            cd([path '\Functions\tsfMRI\' num2str(kk)])
            load([ROI{index},'.mat']);
            cd([path '\Results\' num2str(kk)]);
            rp = load('rp_smImage.txt');
            RegBasFuc = [ones(length(rp),1),(1:length(rp))']; %,rp
            [Beta,~,Residual] = regress(ram(:),RegBasFuc);
            ram = Residual + Beta(1);
            ram_baseline = mean(ram(1:40));
            ram = (ram-ram_baseline)/ram_baseline*100;
            ram([1:30,end-9:end-0]) = [];
            ram_reshape = reshape(ram(:),[numel(stimulus_paradigm),numel(ram)/numel(stimulus_paradigm)]);
            ram_data = [ram_data ram_reshape];
        end
    end
    %% Figure plot
    Series(1) = struct('name',ROI{index},'data',ram_data,'stimulus',stimulus_paradigm);
    title_txt = ROI{index};
    F = MY_get_figure_ROI_Time_Course_single_stimulus_all_scans(Series,title_txt);
    cd(save_path);
    saveas(F,[strcat(ROI{index},'_averaged'),'.tif'])
    close all;clear ra*
end
