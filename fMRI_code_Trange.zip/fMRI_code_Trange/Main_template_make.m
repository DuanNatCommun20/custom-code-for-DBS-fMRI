%% preparation
% According to your experimental parameters and certain file direction, Change these bellow.
clc;clear
codepath = 'D:\puk_resubmit\fMRI_code_Trange\';
cd(codepath);
addpath(genpath(codepath));
% template = [codepath '\Template_Trange_Guangzhou.nii'];
% Gmask    = [codepath 'GS_mask.nii'];

Animal_path{1} = 'D:\puk_resubmit\20170509_115719_pku_3_0509_1_1\'; % 3_1
Animal_path{2} = 'D:\puk_resubmit\20170512_160554_pku_0512_5_1_1\'; % 5_1
% Animal_path{3} = 'D:\puk_resubmit\20170619_125151_pku_0619_5_1_1\'; % 5
Animal_path{3} = 'D:\puk_resubmit\20170814_152685_20170814_pku_11_1_1_1\'; % 11
Animal_path{4} = 'D:\puk_resubmit\20170815_135043_20170815_pku_12_1_1_1\'; % 12 *
Animal_path{5} = 'D:\puk_resubmit\20170816_092332_20170816_pku_13_1_1_1\'; % 13
Animal_path{6} = 'D:\puk_resubmit\20170816_131011_20170816_pku_14_1_1_1\'; % 14
Animal_path{7} = 'D:\puk_resubmit\20170816_160858_20170816_pku_15_1_1_1\'; % 15
Animal_path{8} = 'D:\puk_resubmit\20170818_095606_20170818_pku_16_1_1_1\'; % 16
Animal_path{9} = 'D:\puk_resubmit\20170818_122838_20170818_pku_17_1_1_2\'; % 17

Animal_T2RARE = {6 12 33 4 5 4 3 3 2};

% for number = 1:numel(Animal_path)
%     path = Animal_path{number};
%     T2 = Animal_T2RARE{number};
% %     copyfile([path,'\Results\T2\T2_m.nii'],['D:\puk_resubmit\Template_make\']);
%     cd('D:\puk_resubmit\Template_make\')
% %     eval(['!rename',',T2_m.nii,',[num2str(number),'.nii'],';']);
%     ref{1,1} = ['D:\puk_resubmit\Template_make\X.nii,1'];
%     source{1,1} = ['D:\puk_resubmit\Template_make\' num2str(number) '.nii,1'];
%     T22Template_mlb = MY_get_default_coreg_batch_struct(ref, source, {''});
%     disp('Start to process OldNormalize!');
%     F = spm_figure('GetWin');
%     spm_jobman('run',T22Template_mlb);
%     hgexport(figure(F), fullfile(pwd,'\', num2str(number)), hgexport('factorystyle'), 'Format', 'tiff');
% end


%%
%{
template = ['D:\puk_resubmit\20190929_140015_20190929_pku_lg_rat3_1_1\Results\T2' '\srT2_m.nii'];

 cd('D:\puk_resubmit\Template_make\')
for number = 1:numel(Animal_path)
    head = spm_vol('4.nii');
    img(:,:,:,number) = spm_read_vols(spm_vol(['c',num2str(number),'.nii']));
end
Img_mean = mean(img,4);
Img_mean(:,:,[1 18:20]) = [];
Img_mean(:,[1:10 150:256],:) = [];
Img_mean([1:28+5 219-5:256],:,:) = [];
head.fname = 'Template.nii';
% Img_mean(66+68-1:-1:66,:,9) = Img_mean(1:68,:,9);
% Img_mean(66+68-1:-1:66,:,10) = Img_mean(1:68,:,10);
% Img_mean(66+68-1:-1:66,:,8) = Img_mean(1:68,:,8);
% Img_mean(67+68-1:-1:68,:,5) = Img_mean(1:67,:,5);
% Img_mean(66+68-1:-1:66,:,4) = Img_mean(1:68,:,4);
% Img_mean(66+68-1:-1:66,:,3) = Img_mean(1:68,:,3);
% Img_mean(66+68-1:-1:66,:,2) = Img_mean(1:68,:,2);
% Img_mean(66+68-1:-1:66,:,1) = Img_mean(1:68,:,1);
% Img_mean2 = zeros([160 130 15]);
% Img_mean2(13:12+136,14:13+102,:)=Img_mean;
head.dim = size(Img_mean);
spm_write_vol(head,Img_mean);
%}

%{
 cd('D:\puk_resubmit\Template_make\')
head = spm_vol('Template.nii');
img = spm_read_vols(head);
img(:,1:25,[1 5 8:15]) = 0;
img(:,1:24,[6 7]) = 0;
img(78+79-1:-1:79,:,3) = img(1:78,:,3);
img(78+79-1:-1:79,:,2) = img(1:78,:,2);
img(78+79-1:-1:79,:,1) = img(1:78,:,1);
img(78+79-1:-1:79,:,4) = img(1:78,:,4);
img(78+79-1:-1:79,:,5) = img(1:78,:,5);
img(78+79-1:-1:79,:,8) = img(1:78,:,8);
img(78+79-1:-1:79,:,9) = img(1:78,:,9);
img(78+79-1:-1:79,:,10) = img(1:78,:,10);
img(78+79-1:-1:79,:,11) = img(1:78,:,11);

head.fname = 'X.nii';
spm_write_vol(head,img);
%}

cd('D:\puk_resubmit\20190929_140015_20190929_pku_lg_rat3_1_1\Results\11');
head = spm_vol('rmrs2dseq.nii');
img0 = spm_read_vols(spm_vol('D:\puk_resubmit\20170816_131011_20170816_pku_14_1_1_1\Results\23\nmrs2dseq.nii'));
img = spm_read_vols(head);
img(:,:,15) = img0(:,:,15,50)/2;
head.fname = 'X.nii';
spm_write_vol(head,img);
