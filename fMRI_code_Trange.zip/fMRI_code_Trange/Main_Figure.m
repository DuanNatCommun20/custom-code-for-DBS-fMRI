%% preparation
% According to your experimental parameters and certain file direction, Change these bellow.
clc;clear
codepath = 'D:\puk_resubmit\fMRI_code_Trange\';
cd(codepath);
addpath(genpath(codepath));
template = [codepath '\Template.nii'];
% Gmask    = [codepath 'GS_mask.nii'];

Animal_path{1} = 'D:\puk_resubmit\20170509_115719_pku_3_0509_1_1\'; 
Animal_path{2} = 'D:\puk_resubmit\20170512_160554_pku_0512_5_1_1\'; 
Animal_path{3} = 'D:\puk_resubmit\20170815_135043_20170815_pku_12_1_1_1\'; 
Animal_path{4} = 'D:\puk_resubmit\20170816_092332_20170816_pku_13_1_1_1\'; 
Animal_path{5} = 'D:\puk_resubmit\20170816_131011_20170816_pku_14_1_1_1\'; 
Animal_path{6} = 'D:\puk_resubmit\20170816_160858_20170816_pku_15_1_1_1\'; 
Animal_path{7} = 'D:\puk_resubmit\20170818_095606_20170818_pku_16_1_1_1\'; 
Animal_path{8} = 'D:\puk_resubmit\20170818_122838_20170818_pku_17_1_1_2\'; 

Animal_EPI_name = {'10Hz';'100Hz';'130Hz';'250Hz'};
Animal_EPI_folder{1} = {[10:13];[19:22];[27 28 29 31];[14:17]};
Animal_EPI_folder{2} = {[26:29];[34:37];[38 39 40 42];[30:33]};
Animal_EPI_folder{3} = {[31 32 33];[17 18 30];[14 15 16];[34 35 36]};
Animal_EPI_folder{4} = {[16 17 18];[13 14 15];[09 11 12];[19 20 21]};
Animal_EPI_folder{5} = {[22 23 24];[19 20 21];[18 29 30];[25 26 27]};
Animal_EPI_folder{6} = {[08 09 10];[18 22 24];[14 16 17];[11 12 13]};
Animal_EPI_folder{7} = {[14 15 16];[11 12 13];[07 09 10];[17 18 19]};
Animal_EPI_folder{8} = {[14 15 16];[11 12 13];[07 09 10];[17 18 19]};
%% Figure 04  XXX
%{
a_10 = 0; a_100 = 0; a_130 = 0; a_250 = 0;
freq = [10 100 130 250];
for number = 1:9
    path = Animal_path{number};
    EPI_folder = Animal_EPI_folder{number};
    for k = 1:numel(EPI_folder)
        sub_folder = EPI_folder{k};
        for j = 1:numel(sub_folder)
            head = spm_vol([path 'Functions\tsfMRI\',num2str(sub_folder(j)),'\spmT_0001.nii']);
            img = spm_read_vols(head);
            eval(['a_',num2str(freq(k)),'=a_',num2str(freq(k)),'+1;'])
            eval(['spmT_',num2str(freq(k)),'(:,:,:,a_',num2str(freq(k)),')=img;'])
            
        end
        
    end
end
mkdir('D:\puk_resubmit\Figure\group\')
cd('D:\puk_resubmit\Figure\group\')
for k = 1:numel(EPI_folder)
    eval(['head.fname = ''spmT_',num2str(freq(k)),'.nii'';']);
    eval(['img = mean(spmT_',num2str(freq(k)),',4);']);
    spm_write_vol(head,img);

    
    eval(['spmT_file = ''spmT_',num2str(freq(k)),'.nii'';']);
    Colormap(   'statfile',spmT_file,...
                'bgmfile',template,...
                'slice',15:-1:1,...
                'bar_value',[-5 -3.001 1.001 3],...
                'dest',pwd,...
                'mapname',['tmap_',num2str(freq(k))],...
                'cluster',10);%,...
end
%}

%% Figure 04
%{
a_10 = 0; a_100 = 0; a_130 = 0; a_250 = 0;
freq = [10 100 130 250];
for number = [1:8]
    path = Animal_path{number};
    EPI_folder = Animal_EPI_folder{number};
    for k = 1:numel(EPI_folder)
        
        cd([path,'Functions\tsfMRI\Allscans_',num2str(freq(k))])
        head = spm_vol('spmT_0001.nii');
        img = spm_read_vols(head);
        eval(['a_',num2str(freq(k)),'=a_',num2str(freq(k)),'+1;'])
        eval(['spmT_',num2str(freq(k)),'(:,:,:,a_',num2str(freq(k)),')=img;'])
        
    end
end
mkdir('D:\puk_resubmit\Figure\group\')
cd('D:\puk_resubmit\Figure\group\')
for k = 1:numel(EPI_folder)
    eval(['head.fname = ''spmT_',num2str(freq(k)),'.nii'';']);
    eval(['img = mean(spmT_',num2str(freq(k)),',4);']);
    spm_write_vol(head,img);
colorbar = [-8 -5 2.0 8];
     if k == 3;colorbar = [-8 -5 2.0 6];end
    eval(['spmT_file = ''spmT_',num2str(freq(k)),'.nii'';']);
    Colormap(   'statfile',spmT_file,...
                'bgmfile',template,...
                'slice',15:-1:4,...
                'bar_value',colorbar,...
                'dest',pwd,...
                'mapname',['tmap_',num2str(freq(k))],...
                'cluster',10,...
                'adjust_method','no',...
                'corrected_p',0.001);%,...
end
%}

%% Figure Suppl.
%{
freq = [10 100 130 250];
for number = 1:8
    path = Animal_path{number};
    EPI_folder = Animal_EPI_folder{number};
    for k = 1:numel(EPI_folder)
        dest = [path,'Functions\tsfMRI\Allscans_',num2str(freq(k))];
        cd(dest);
        template = ['D:\puk_resubmit\20190929_140015_20190929_pku_lg_rat3_1_1\Results\11\X.nii,1'];
        spmT_file = [dest '\spmT_0001.nii']; 
        colorbar = [-10 -5 2 8];
        Colormap(   'statfile',spmT_file,...
            'bgmfile',template,...
            'slice',15:-1:4,...
            'bar_value',colorbar,...
            'dest',pwd,...
            'mapname',['tmap_',num2str(freq(k))],...
                'cluster',100,...
                'adjust_method','no',...
                'corrected_p',0.001);%,...
    end
end


% fig2PPTX
freq = [10 100 130 250];
PPT_length = 16;PPT_width = 9;
cd('D:\puk_resubmit\Figure\group\')
try
    exportToPPTX('close');
    exportToPPTX('open', 'tsfMRI.pptx');
catch
    exportToPPTX('new','Dimensions',[PPT_length PPT_width]);
end

for k = 1:numel(freq)
    exportToPPTX('addslide');
    for number = 1:8
        path = Animal_path{number};
        dest = [path,'Functions\tsfMRI\Allscans_',num2str(freq(k))];
        cd(dest);
        img = imread(strcat('tmap_',num2str(freq(k)),'.tif'));
        ppt_fig_ud = PPT_length*size(img,1)/size(img,2);
        ppt_fig_lr = PPT_length;
        exportToPPTX('addpicture',img,'Position',[0 ppt_fig_ud*(number-1) ppt_fig_lr ppt_fig_ud],'Scale','noscale');
    end
end
cd('D:\puk_resubmit\Figure\group\')
exportToPPTX('save', 'tsfMRI.pptx');
exportToPPTX('close');
%}



