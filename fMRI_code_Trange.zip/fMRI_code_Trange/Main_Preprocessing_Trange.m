%% preparation
clc;clear
codepath = 'D:\puk_resubmit\fMRI_code_Trange\';
Animal_path{1} = 'D:\puk_resubmit\20170509_115719_pku_3_0509_1_1\'; % 3_1

%Animal_EPI_name = {'10Hz';'100Hz';'130Hz';'250Hz'};
%Animal_EPI_folder{1} = {[10:13];[19:22];[27 28 29 31];[14:17]};
Animal_EPI_name = {'130Hz';};
Animal_EPI_folder{1} = {[27];};
Animal_T2RARE = {6};


%% regressor choices
Reg_choices = {'rp';};
% no     --->  no regression
% rp    --->  6 head motion parameters regression [rp]
% rp"   --->  the deviation of 6 head motion parameters regression [rp']
% rp2   --->  the square of rp and rp" [rp.^2 rp'.^2]
cd(codepath);
addpath(genpath(codepath));
template = [codepath '\Template.nii'];
Gmask    = [codepath 'GS_mask.nii'];


for number = 1
    path = Animal_path{number};
    EPI_folder = spm_cat(Animal_EPI_folder{number});
    EPI_folder = full(EPI_folder(:));
    RARE = Animal_T2RARE{number};
    spm('defaults', 'FMRI');
    set(spm('CreateIntWin','off'),'Visible','on');
    
    for flag_stage = [10] 
        if flag_stage == 1
            %% Bruker2nifiti
            Bruker2nifti_multislice(path,EPI_folder,'rat');
            Bruker2nifti_multislice(path,RARE,'rat');
        end
        if flag_stage == 2
            %% Slicetiming
            for i = 1:numel(EPI_folder)
                kk = EPI_folder(i);
                cd([path '\Results\',num2str(kk)]);delete('*.mat');
                Segments = MY_search_bruker_method('Segments',kk,path);
                EPI_TR = MY_search_bruker_method('EPI_TR',kk,path)/1000*Segments;
                Nslice = MY_search_bruker_method('Nslice',kk,path);
                all_func = MY_find_images_in_all_scans(path,'Results',{kk},'^2dseq','.nii',[1 Inf],'separate_cells');
                slicetiming_mlb = MY_get_default_slicetiming_batch_struct(all_func,Nslice,EPI_TR);
                disp('Start to process Slicetiming!')
                spm_jobman('run',slicetiming_mlb);
            end
        end
        if flag_stage == 3
            %% Realignment
            all_func = MY_find_images_in_all_scans(path,'Results',{EPI_folder(:)},'^s2dseq','.nii',[1 Inf],'separate_cells');
            realign_mlb = MY_get_default_realign_batch_struct(all_func);
            F = spm_figure('GetWin');
            disp('Start to process realignment !')
            spm_jobman('run',realign_mlb);
            hgexport(figure(F), fullfile([path,'Results\'],strcat('realign')), hgexport('factorystyle'), 'Format', 'tiff');
            clear realign_mlb all_func;
        end
        if flag_stage == 4
            %% mask all EPI and RARE
            cd([path 'Results']);
            EPI_mask = spm_read_vols(spm_vol('EPI_mask.nii'));
            T2_mask = spm_read_vols(spm_vol('T2_mask.nii'));
            MY_mask_images(path,EPI_folder,'rs2dseq.nii',EPI_mask,'Rmrs2dseq.nii','EPI');
            MY_mask_images(path,RARE,'2dseq.nii',T2_mask,'T2_m.nii','T2');
        end        
        if flag_stage == 5
            %% Func2T2 Coregistration
            source{1,1} = [path 'Results\' num2str(EPI_folder(1)) '\means2dseq.nii,1'];
            ref{1,1} = [path 'Results\T2\T2_m.nii,1'];
            all_func = MY_find_images_in_all_scans(path,'Results',{EPI_folder(:)},'^Rmrs2dseq','.nii',[1 Inf],'all_mixed');
            Func2T2W_mlb = MY_get_default_coreg_batch_struct(ref, source, all_func);
            disp('Start to process Func2T2W coregistration!');
            F = spm_figure('GetWin');
            spm_jobman('run',Func2T2W_mlb);
            hgexport(figure(F), fullfile([path 'Results\'], 'coreg'), hgexport('factorystyle'), 'Format', 'tiff');
            clear Func2T2W_mlb other ref source;
        end
        if flag_stage == 6
            %% T22Template coregistration   
            ref{1,1} = [path 'Results\Template.nii'];
            source{1,1} = [path 'Results\T2\T2_m.nii,1'];
            all_func = MY_find_images_in_all_scans(path,'Results',{EPI_folder(:)},'^cRmrs2dseq','.nii',[1 Inf],'all_mixed');
            head = spm_vol(ref{1,1});
            re_voxel = sqrt(sum(head.mat(1:3,1:3).^2));
            re_voxel(3) = re_voxel(3)*0.99;
            oldnormalize_mlb = MY_get_default_oldnormalize_batch_struct(ref, source, all_func, re_voxel);%, re_voxel
            disp('Start to process OldNormalize!');
            F = spm_figure('GetWin');
            spm_jobman('run',oldnormalize_mlb);
            hgexport(figure(F), fullfile([path 'Results\'], strcat('oldnormalize')), hgexport('factorystyle'), 'Format', 'tiff');
            clear OldNormalize_mlb other ref source;
        end
        if flag_stage == 7
            %% smooth_space 
            all_func = MY_find_images_in_all_scans(path,'Results',{EPI_folder(:)},'^ncRmrs2dseq','.nii',[1 Inf],'all_mixed');
            Smooth_mlb = MY_get_default_smooth_batch_struct(all_func);
            disp('Start to process Smooth!');
            spm_jobman('run',Smooth_mlb);
            clear Smooth_mlb;
        end
        if flag_stage == 8
            %% tsfMRI
            duration = [30]; % block analysis
            onset = [60-4];
            colorbar = [-6 -1.5 1.5 6];
            template = [codepath '\Template.nii,1'];
            
            result_1st = struct('weights',1,'slice',15:-1:1,'template',template,'FDR_pvalue',0.05,'colorbar',colorbar);
            %% individual
            defined_1st = struct('Nscans','individual','filename','snRmrs2dseq','duration',duration,'onset',onset);
            MY_task_state_statistics(path,'Results',{EPI_folder(:)},[1 Inf],Reg_choices,defined_1st,result_1st);
            %% Allscans
            freq = [10 100 130 250];
            folder_ram = Animal_EPI_folder{number};
            for i = 1:numel(folder_ram)
                folder = folder_ram{i};
                defined_1st = struct('Nscans','Allscans','filename','sncRmrs2dseq','duration',duration,'onset',onset);
                MY_task_state_statistics(path,'Results',{folder(:)},[1 Inf],Reg_choices,defined_1st,result_1st);
                cd([path '\Functions\tsfMRI'])
                eval(['!rename,Allscans,Allscans_',num2str(freq(i))]);
            end
        end
        
    end
end