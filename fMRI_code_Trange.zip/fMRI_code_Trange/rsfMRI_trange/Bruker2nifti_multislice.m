function Bruker2nifti_multislice(Main_path,folder,species)

% FUNCTION Bruker2nifti.m
% Extracts scanner parameters and builds the Nifti volume


for i = 1:numel(folder)
    kk = folder(i);
    pars            =   get_pars([Main_path,num2str(kk),'\pdata\1\2dseq']);
    switch lower(pars.method)
        case {'fieldmap'}
            subfolder = 1:2;
        otherwise
            subfolder = 1;
    end
    for jj = subfolder
        path = [Main_path,num2str(kk),'\pdata\',num2str(jj),'\2dseq'];
        pars            =   get_pars(path);
        Img             =   read_seq(path,pars); 

        switch lower(pars.method)
            case {'rare'}
                dt = 8;
                outpath = [Main_path,'Results\T2'];
            case {'epi'}
                dt = 4;
                outpath = [Main_path,'Results\',num2str(kk)];
            case {'fieldmap'}
                dt = 16;
                outpath = [Main_path,'Results\FieldMap',num2str(jj)];
        end
        
        
        switch lower(species)
            case {'mouse'};      Voxel_Multiple = 20;
            case {'rat'};        Voxel_Multiple = 10;
            case {'marmoset'};   Voxel_Multiple = 6;
            case {'monkey'};     Voxel_Multiple = 2;
            case {'human'};      Voxel_Multiple = 1;
        end
        pars.resol = pars.resol * Voxel_Multiple;
        pars.pos0  = pars.pos0  * Voxel_Multiple;
        
        % Converts Vol to Nifti format with the help of all the image parameters
        % (or=orientation, r_out=readout, idist=scanner isodist, m_or=orientation
        % matrix, dims= dimensions, FOV=field of view, resol=resolution,
        % offset=scanner offset, tp= data type)
        
        or      =   pars.orient;
        orient  =   pars.m_or;
        dims    =   pars.dims;
        resol   =   pars.resol;   %in mm
        tp      =   pars.tp;
        pos0    =   pars.pos0;
        vect    =   pars.vect;
        
        
        
        %datatype__________________________________________________________________
        %		2 - uint8,  4 - int16,  8 - int32,  16 - float32,
        %		32 - complex64,  64 - float64,  128 - RGB24,
        %		256 - int8,  511 - RGB96,  512 - uint16,
        %		768 - uint32,  1792 - complex128
        
        %         types   = [    2      4      8   16   64   256    512    768];
        %         dt = 0;
        %         for j=1:size(prec,2)
        %             if strcmp(tp,prec(1,j)),dt=types(j); end
        %         end
        
        dims        =   dims(vect);
        
        %MATRIX________________________________________________________________
        orig = pos0./resol;
        off  = double(orig(1:3)).*double(resol(1:3));
        mat  = [ resol(1)     0         0      off(1)
            0      resol(2)     0      off(2)
            0         0      resol(3)  off(3)
            0         0         0        1   ];
        
        if strcmp(or,'axial')
            mat             =   spm_matrix([0 0 0 pi/2 0 0 1 1 1])*mat;
        elseif strcmp(or,'sagittal')
            mat             =   spm_matrix([0 0 0 0 -pi/2 pi 1 1 1])*mat;
        end
        
        
        % Write
        if ~exist(outpath,'dir'), mkdir(outpath);end
        path_out=[outpath '\' '2dseq.nii'];
        for k = 1:size(Img,4)
            Vol(k,1) = struct(  'fname',    path_out,...
                                'dim',      double(dims'),...
                                'mat',      mat,...
                                'n',        [k,1],...
                                'pinfo',    [1;0;0],...
                                'descrip',  ['fm_',species,' image'],...
                                'dt',       [dt 0]);
        end
        spm_write_vol_4D(Vol,Img);
        
    end
end
end


