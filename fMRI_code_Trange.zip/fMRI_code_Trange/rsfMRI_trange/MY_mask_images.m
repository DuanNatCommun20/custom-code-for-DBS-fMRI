function MY_mask_images(path,folder,file_name,mask,output_file_name,file_type)


for i = 1:numel(folder)
    kk = folder(i);
    switch file_type
        case 'EPI'
            file_path = [path,'Results\',num2str(kk),'\'];
            head = spm_vol([file_path,file_name]);
            img_RAM = fmask(spm_read_vols(head),mask);
            %% detrend
            img = funmask(img_RAM,mask);
            for i = 1:numel(head)
               head(i).fname = [file_path,output_file_name]; 
            end
            
            spm_write_vol_4D(head,img);
 
        case 'Fieldmap'
            for jj = 1:2
                file_path = [path,'Results\FieldMap',num2str(jj),'\'];
                head = spm_vol([file_path,file_name]);
                img = spm_read_vols(head).*mask;
                head.fname = [file_path,output_file_name]; 
                spm_write_vol_4D(head,img);
            end
        case 'T2'
            file_path = [path,'Results\T2\'];
            head = spm_vol([file_path,file_name]);
            img = spm_read_vols(head).*mask;
            head.fname = [file_path,output_file_name]; 
            spm_write_vol_4D(head,img);
    end
    
end
end

